// Authentication JavaScript - Backend Connected Version

const API_BASE_URL = 'http://localhost:5000/api';

// Check if user is already logged in
function checkAuth() {
    const currentUser = localStorage.getItem('currentUser');
    const isLoginPage = window.location.pathname.includes('login.html') || 
                       window.location.pathname === '/' ||
                       window.location.pathname === '/index.html' && !currentUser;
    
    if (currentUser && isLoginPage) {
        const user = JSON.parse(currentUser);
        if (user.role === 'admin') {
            window.location.href = 'index.html';
        } else {
            window.location.href = 'user-dashboard.html';
        }
        return true;
    } else if (!currentUser && !isLoginPage && window.location.pathname !== '/') {
        window.location.href = 'login.html';
        return false;
    }
    
    return !!currentUser;
}

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    initializeDarkMode();
    
    // Check authentication status
    checkAuth();
    
    // Login form handler
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Toggle password visibility
    const togglePassword = document.getElementById('togglePassword');
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    }
    
    // Theme toggle
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleDarkMode);
    }
    
    // Remember me functionality
    const rememberMe = document.getElementById('rememberMe');
    const usernameInput = document.getElementById('username');
    
    if (rememberMe && usernameInput) {
        const savedUsername = localStorage.getItem('rememberedUsername');
        if (savedUsername) {
            usernameInput.value = savedUsername;
            rememberMe.checked = true;
        }
    }
    
    // Credential click handlers
    const credentialItems = document.querySelectorAll('.credential-item');
    credentialItems.forEach(item => {
        item.addEventListener('click', function() {
            const username = this.dataset.username;
            const password = this.dataset.password;
            
            document.getElementById('username').value = username;
            document.getElementById('password').value = password;
            
            // Show visual feedback
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 200);
        });
    });
});

// Handle login form submission
async function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('rememberMe').checked;
    const loginButton = document.getElementById('loginButton');
    const buttonLoader = loginButton.querySelector('.button-loader');
    
    if (!username || !password) {
        showAlert('Please enter both username and password', 'error');
        return;
    }
    
    // Show loading state
    loginButton.classList.add('loading');
    loginButton.disabled = true;
    buttonLoader.style.display = 'block';
    
    try {
        // Make API call to backend
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            // Save username if remember me is checked
            if (rememberMe) {
                localStorage.setItem('rememberedUsername', username);
            } else {
                localStorage.removeItem('rememberedUsername');
            }
            
            // Create session
            const session = {
                username: data.user.username,
                role: data.user.role,
                name: data.user.name,
                loginTime: new Date().toISOString()
            };
            
            localStorage.setItem('currentUser', JSON.stringify(session));
            
            // Show success message
            showAlert('Login successful! Redirecting...', 'success');
            
            // Redirect based on role
            setTimeout(() => {
                if (data.user.role === 'admin') {
                    window.location.href = 'index.html';
                } else {
                    window.location.href = 'user-dashboard.html';
                }
            }, 1000);
        } else {
            showAlert(data.error || 'Invalid username or password', 'error');
            loginButton.classList.remove('loading');
            loginButton.disabled = false;
            buttonLoader.style.display = 'none';
        }
    } catch (error) {
        console.error('Login error:', error);
        showAlert('Connection error. Please check if the backend server is running.', 'error');
        loginButton.classList.remove('loading');
        loginButton.disabled = false;
        buttonLoader.style.display = 'none';
    }
}

// Show alert message
function showAlert(message, type = 'error') {
    const alertMessage = document.getElementById('alertMessage');
    const alertText = document.getElementById('alertText');
    
    if (!alertMessage || !alertText) return;
    
    alertText.textContent = message;
    alertMessage.className = 'alert-message';
    
    if (type === 'success') {
        alertMessage.classList.add('success');
    }
    
    alertMessage.style.display = 'flex';
    
    if (type === 'error') {
        setTimeout(() => {
            alertMessage.style.display = 'none';
        }, 5000);
    }
}

// Logout function
function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = 'login.html';
}

// Get current user
function getCurrentUser() {
    const userStr = localStorage.getItem('currentUser');
    return userStr ? JSON.parse(userStr) : null;
}

// Dark Mode Functions
function initializeDarkMode() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
}

function toggleDarkMode() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    if (navigator.vibrate) {
        navigator.vibrate(50);
    }
}