// Main Dashboard Script - Contractor List with Backend Integration

let rowCounter = 0;
let savedData = [];
const STORAGE_KEY = 'dashboardData';
const API_BASE_URL = 'http://localhost:5000/api';

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeDarkMode();
    updateUserProfile();
    setupLogout();
    loadDataWithBackend();
    setupEventListeners();
    updateTotalCount();
    setupMobileMenu();
    
    setTimeout(() => {
        checkAllDurations();
    }, 500);
});

// Load data from backend first, then localStorage as fallback
async function loadDataWithBackend() {
    try {
        const response = await fetch(`${API_BASE_URL}/contractor-list`);
        if (response.ok) {
            const backendData = await response.json();
            if (backendData && backendData.length > 0) {
                console.log('Loading data from backend:', backendData.length, 'records');
                loadDataFromArray(backendData, true);
                return;
            }
        }
    } catch (error) {
        console.log('Backend not available, loading from localStorage');
    }
    
    // Fallback to localStorage
    loadData();
}

// Load data from array (backend or localStorage)
function loadDataFromArray(dataArray, isBackend = false) {
    const tbody = document.getElementById('tableBody');
    tbody.innerHTML = '';
    
    dataArray.forEach((rowData, index) => {
        const row = document.createElement('tr');
        const snoValue = rowData.sno || (index + 1);
        rowCounter = Math.max(rowCounter, parseInt(snoValue) || index + 1);
        
        let isWarning = false;
        if (rowData.duration && rowData.duration.includes('days')) {
            const daysMatch = rowData.duration.match(/(\d+)\s*days/);
            if (daysMatch) {
                const days = parseInt(daysMatch[1]);
                isWarning = days <= 60;
            }
        }
        
        const contractorValue = rowData.contractor || '';
        const fileName = isBackend ? rowData.file_name : rowData.fileName;
        const fileBase64 = isBackend ? rowData.file_base64 : rowData.fileBase64;
        const fileType = isBackend ? rowData.file_type : rowData.fileType;
        const startDate = isBackend ? rowData.start_date : rowData.startDate;
        const endDate = isBackend ? rowData.end_date : rowData.endDate;
        const hasFile = fileName && fileBase64;
        
        row.innerHTML = `
            <td><input type="text" class="sno-input" placeholder="S.No" value="${snoValue}"></td>
            <td><input type="text" class="efile-input" placeholder="E-File" value="${rowData.efile || ''}"></td>
            <td>
                <input type="text" class="contractor-input" placeholder="Contractor" value="${contractorValue}" ${hasFile ? 'style="display: none;"' : ''}>
                <a href="#" class="contractor-link" ${hasFile ? 'style="display: inline-block; color: var(--accent-primary); text-decoration: underline; cursor: pointer;"' : 'style="display: none;"'}">${contractorValue}</a>
            </td>
            <td><input type="text" class="description-input" placeholder="Description" value="${rowData.description || ''}"></td>
            <td><input type="text" class="value-input" placeholder="Value" value="${rowData.value || ''}"></td>
            <td>
                <div class="date-input-wrapper">
                    <input type="date" class="start-date-input" id="startDate${index}" value="${startDate || ''}">
                    <label for="startDate${index}" class="calendar-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </label>
                </div>
            </td>
            <td>
                <div class="date-input-wrapper">
                    <input type="date" class="end-date-input" id="endDate${index}" value="${endDate || ''}">
                    <label for="endDate${index}" class="calendar-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </label>
                </div>
            </td>
            <td class="duration-cell ${isWarning ? 'warning' : ''}">
                <span class="duration-display">${rowData.duration || '-'}</span>
            </td>
            <td>
                <input type="file" class="attachment-input" accept="*/*">
                <span class="file-name" style="color: var(--accent-primary); font-size: 12px;">${fileName || ''}</span>
            </td>
            <td>
                <button class="delete-btn" onclick="deleteRow(this)">
                    <i class="fas fa-trash"></i> <span>Delete</span>
                </button>
            </td>
        `;
        
        tbody.appendChild(row);
        
        if (hasFile && fileBase64) {
            try {
                const file = base64ToFile(fileBase64, fileName);
                const fileInput = row.querySelector('.attachment-input');
                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(file);
                fileInput.files = dataTransfer.files;
                
                const contractorLink = row.querySelector('.contractor-link');
                const fileUrl = URL.createObjectURL(file);
                contractorLink.href = '#';
                contractorLink.dataset.objectUrl = fileUrl;
                contractorLink.dataset.fileName = file.name;
                
                contractorLink.replaceWith(contractorLink.cloneNode(true));
                const newLink = row.querySelector('.contractor-link');
                
                newLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    openFileVisually(fileUrl, file.name, file.type);
                });
            } catch (error) {
                console.error('Error restoring file:', error);
            }
        }
        
        const startDateInput = row.querySelector('.start-date-input');
        const endDateInput = row.querySelector('.end-date-input');
        const fileInput = row.querySelector('.attachment-input');
        const contractorInput = row.querySelector('.contractor-input');
        
        if (startDateInput && endDateInput) {
            startDateInput.addEventListener('change', calculateDuration);
            endDateInput.addEventListener('change', calculateDuration);
        }
        
        if (fileInput) {
            fileInput.addEventListener('change', function(e) {
                validateFileSize(e.target);
                updateContractorHyperlink(row);
            });
        }
        
        if (contractorInput) {
            contractorInput.addEventListener('input', function() {
                updateContractorHyperlink(row);
            });
        }
    });
    
    updateTotalCount();
    setTimeout(() => checkAllDurations(), 300);
}

// Save data to both localStorage and backend
async function saveData() {
    await saveDataToStorage();
    await syncToBackend();
    alert('Data saved successfully to database!');
}

// Sync to backend
async function syncToBackend() {
    const tbody = document.getElementById('tableBody');
    const rows = tbody.querySelectorAll('tr');
    const dataToSync = [];
    
    for (const row of rows) {
        const sno = row.querySelector('.sno-input')?.value || '';
        const efile = row.querySelector('.efile-input')?.value || '';
        const contractorInput = row.querySelector('.contractor-input');
        const contractorLink = row.querySelector('.contractor-link');
        const contractor = contractorInput && contractorInput.style.display !== 'none' 
            ? contractorInput.value 
            : (contractorLink?.textContent || '');
        const description = row.querySelector('.description-input')?.value || '';
        const value = row.querySelector('.value-input')?.value || '';
        const startDate = row.querySelector('.start-date-input')?.value || '';
        const endDate = row.querySelector('.end-date-input')?.value || '';
        const duration = row.querySelector('.duration-display')?.textContent || '-';
        const attachmentInput = row.querySelector('.attachment-input');
        const file = attachmentInput?.files[0];
        
        let fileBase64 = '';
        let fileName = '';
        let fileType = '';
        
        if (file) {
            fileName = file.name;
            fileType = file.type;
            try {
                fileBase64 = await fileToBase64(file);
            } catch (error) {
                console.error('Error converting file:', error);
            }
        }
        
        dataToSync.push({
            sno, efile, contractor, description, value, 
            startDate, endDate, duration,
            fileName, fileBase64, fileType
        });
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/contractor-list`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ records: dataToSync })
        });
        
        if (response.ok) {
            const result = await response.json();
            console.log('Data synced to backend:', result);
        } else {
            console.error('Failed to sync to backend');
        }
    } catch (error) {
        console.error('Error syncing to backend:', error);
    }
}

// Setup event listeners
function setupEventListeners() {
    document.getElementById('addRowBtn').addEventListener('click', addRow);
    document.getElementById('saveBtn').addEventListener('click', saveData);
    document.getElementById('refreshBtn').addEventListener('click', refreshPage);
    document.getElementById('printBtn').addEventListener('click', printTable);
    document.getElementById('exportBtn').addEventListener('click', exportToExcel);
    
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            filterTable(e.target.value);
        });
    }
    
    const notificationBellBtn = document.getElementById('notificationBellBtn');
    if (notificationBellBtn) {
        notificationBellBtn.addEventListener('click', openNotificationModal);
    }
    
    const closeNotificationBtn = document.getElementById('closeNotification');
    if (closeNotificationBtn) {
        closeNotificationBtn.addEventListener('click', closeNotification);
    }
    
    const notificationModal = document.getElementById('notificationModal');
    if (notificationModal) {
        notificationModal.addEventListener('click', function(e) {
            if (e.target === notificationModal) {
                closeNotification();
            }
        });
    }
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeNotification();
        }
    });
}

// Add new row with calendar icon
function addRow() {
    const tbody = document.getElementById('tableBody');
    const row = document.createElement('tr');
    rowCounter++;
    
    row.innerHTML = `
        <td>
            <input type="text" class="sno-input" placeholder="S.No" value="${rowCounter}">
        </td>
        <td>
            <input type="text" class="efile-input" placeholder="E-File">
        </td>
        <td>
            <input type="text" class="contractor-input" placeholder="Contractor">
            <a href="#" class="contractor-link" style="display: none;" target="_blank"></a>
        </td>
        <td>
            <input type="text" class="description-input" placeholder="Description">
        </td>
        <td>
            <input type="text" class="value-input" placeholder="Value">
        </td>
        <td>
            <div class="date-input-wrapper">
                <input type="date" class="start-date-input" id="startDate${rowCounter}">
                <label for="startDate${rowCounter}" class="calendar-icon">
                    <i class="fas fa-calendar-alt"></i>
                </label>
            </div>
        </td>
        <td>
            <div class="date-input-wrapper">
                <input type="date" class="end-date-input" id="endDate${rowCounter}">
                <label for="endDate${rowCounter}" class="calendar-icon">
                    <i class="fas fa-calendar-alt"></i>
                </label>
            </div>
        </td>
        <td class="duration-cell">
            <span class="duration-display">-</span>
        </td>
        <td>
            <input type="file" class="attachment-input" accept="*/*">
            <span class="file-name"></span>
        </td>
        <td>
            <button class="delete-btn" onclick="deleteRow(this)">
                <i class="fas fa-trash"></i> <span>Delete</span>
            </button>
        </td>
    `;
    
    tbody.appendChild(row);
    
    const startDateInput = row.querySelector('.start-date-input');
    const endDateInput = row.querySelector('.end-date-input');
    
    startDateInput.addEventListener('change', calculateDuration);
    endDateInput.addEventListener('change', calculateDuration);
    
    const fileInput = row.querySelector('.attachment-input');
    fileInput.addEventListener('change', function(e) {
        validateFileSize(e.target);
        updateContractorHyperlink(row);
    });
    
    const contractorInput = row.querySelector('.contractor-input');
    contractorInput.addEventListener('input', function() {
        updateContractorHyperlink(row);
    });
    
    updateTotalCount();
}

// Calculate duration between dates
function calculateDuration(event) {
    const row = event.target.closest('tr');
    const startDateInput = row.querySelector('.start-date-input');
    const endDateInput = row.querySelector('.end-date-input');
    const durationDisplay = row.querySelector('.duration-display');
    const durationCell = durationDisplay.parentElement;
    
    if (startDateInput.value && endDateInput.value) {
        const startDate = new Date(startDateInput.value);
        const endDate = new Date(endDateInput.value);
        
        if (endDate >= startDate) {
            const diffTime = endDate - startDate;
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            
            durationDisplay.textContent = `${diffDays} days left`;
            durationCell.classList.remove('warning');
            
            if (diffDays <= 60) {
                durationCell.classList.add('warning');
                showDurationNotification(row, diffDays);
            }
        } else {
            durationDisplay.textContent = 'Invalid dates';
            durationCell.classList.add('warning');
        }
    } else {
        durationDisplay.textContent = '-';
        durationCell.classList.remove('warning');
    }
    
    saveDataToStorage();
    updateNotificationCount();
}

// Continue with remaining functions from original script.js...
// (Include all other functions: updateContractorHyperlink, showDurationNotification, 
// openNotificationModal, closeNotification, updateNotificationCount, getWarningCount,
// checkAllDurations, deleteRow, saveDataToStorage, loadData, refreshPage, printTable,
// exportToExcel, updateTotalCount, filterTable, and auto-save listeners)