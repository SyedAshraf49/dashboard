// User Dashboard JavaScript - Complete Fixed Version
// Part 1: Core Functions and Authentication

document.addEventListener('DOMContentLoaded', function() {
    console.log('User Dashboard Loading...');
    initializeDarkMode();
    checkUserAuth();
    displayUserInfo();
    setupEventListeners();
    setupProfileDropdown();
    addNotificationStyles();
    console.log('User Dashboard Loaded Successfully');
});

// Authentication Check
function checkUserAuth() {
    const currentUser = localStorage.getItem('currentUser');
    
    if (!currentUser) {
        console.log('No user session found, redirecting to login...');
        window.location.href = 'login.html';
        return;
    }
    
    try {
        const user = JSON.parse(currentUser);
        console.log('Current user:', user);
        
        if (user.role === 'admin') {
            console.log('Admin user detected, redirecting to admin dashboard...');
            window.location.href = 'index.html';
            return;
        }
    } catch (error) {
        console.error('Error parsing user data:', error);
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
    }
}

// Display User Information
function displayUserInfo() {
    const currentUser = localStorage.getItem('currentUser');
    
    if (currentUser) {
        try {
            const user = JSON.parse(currentUser);
            console.log('Displaying user info:', user);
            
            // Update welcome title
            const welcomeTitle = document.getElementById('welcomeTitle');
            if (welcomeTitle) {
                welcomeTitle.textContent = `Hello, ${user.name || user.username}!`;
            }
            
            // Update main card username
            const userNameElement = document.getElementById('userName');
            if (userNameElement) {
                userNameElement.textContent = user.name || user.username;
            }

            // Update dropdown username
            const dropdownUserName = document.getElementById('dropdownUserName');
            if (dropdownUserName) {
                dropdownUserName.textContent = user.name || user.username;
            }
            
            // Update role
            const userRole = document.getElementById('userRole');
            if (userRole) {
                userRole.textContent = user.role === 'admin' ? 'Administrator' : 'Standard User';
            }
            
            // Update login time
            const loginTimeElement = document.getElementById('loginTime');
            if (loginTimeElement && user.loginTime) {
                const loginDate = new Date(user.loginTime);
                const formattedTime = loginDate.toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                });
                loginTimeElement.textContent = formattedTime;
            }
        } catch (error) {
            console.error('Error displaying user info:', error);
        }
    }
}

// Dark Mode Functions
function initializeDarkMode() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    console.log('Theme initialized:', savedTheme);
}

function toggleDarkMode() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    console.log('Toggling theme from', currentTheme, 'to', newTheme);
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    // Add smooth transition
    document.body.style.transition = 'background 0.3s ease, color 0.3s ease';
    
    // Haptic feedback if available
    if (navigator.vibrate) { 
        navigator.vibrate(50); 
    }
    
    // Show notification
    showNotification('Theme Changed', `Switched to ${newTheme} mode`, 'success');
}

// Profile Dropdown Setup
function setupProfileDropdown() {
    const profileTrigger = document.getElementById('profileTrigger');
    const profileDropdown = document.getElementById('profileDropdown');
    
    if (profileTrigger && profileDropdown) {
        // Toggle dropdown on click
        profileTrigger.addEventListener('click', function(e) {
            e.stopPropagation();
            console.log('Profile trigger clicked');
            profileDropdown.classList.toggle('active');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!profileDropdown.contains(e.target) && !profileTrigger.contains(e.target)) {
                profileDropdown.classList.remove('active');
            }
        });

        // Prevent dropdown from closing when clicking inside
        profileDropdown.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    }

    // Settings button handler
    const settingsBtn = document.getElementById('settingsBtn');
    if (settingsBtn) {
        settingsBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Settings clicked');
            showNotification(
                'Settings', 
                'Account settings and preferences.\n\nConfigure your dashboard preferences, notifications, and more.',
                'info'
            );
            if (profileDropdown) profileDropdown.classList.remove('active');
        });
    }

    // Preferences button handler
    const preferencesBtn = document.getElementById('preferencesBtn');
    if (preferencesBtn) {
        preferencesBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Preferences clicked');
            showNotification(
                'Preferences', 
                'Customize your dashboard experience.\n\nAdjust display settings, language, and interface preferences.',
                'info'
            );
            if (profileDropdown) profileDropdown.classList.remove('active');
        });
    }

    // Help button handler
    const helpBtn = document.getElementById('helpBtn');
    if (helpBtn) {
        helpBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Help clicked');
            showNotification(
                'Help & Support', 
                'Need assistance? We\'re here to help!\n\n📧 Email: support@dashboard.com\n📞 Phone: +1 (800) 123-4567\n🕐 Hours: Mon-Fri, 9AM-5PM EST',
                'info'
            );
            if (profileDropdown) profileDropdown.classList.remove('active');
        });
    }

    // Privacy button handler
    const privacyBtn = document.getElementById('privacyBtn');
    if (privacyBtn) {
        privacyBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Privacy clicked');
            showNotification(
                'Privacy & Security', 
                'Your data is protected with us.\n\n🔒 End-to-end encryption\n🛡️ Secure data storage\n🔐 Two-factor authentication available',
                'info'
            );
            if (profileDropdown) profileDropdown.classList.remove('active');
        });
    }
}

// Event Listeners Setup
function setupEventListeners() {
    // Logout button handler - CRITICAL FIX
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Logout clicked');
            
            if (confirm('Are you sure you want to logout?')) {
                console.log('Logout confirmed, clearing session...');
                localStorage.removeItem('currentUser');
                console.log('Session cleared, redirecting to login...');
                
                // Force immediate redirect
                window.location.replace('login.html');
                
                // Fallback in case replace doesn't work
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 100);
            } else {
                console.log('Logout cancelled');
                const profileDropdown = document.getElementById('profileDropdown');
                if (profileDropdown) profileDropdown.classList.remove('active');
            }
        });
        console.log('Logout button listener attached');
    } else {
        console.error('Logout button not found!');
    }
    
    // Refresh button handler
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            console.log('Refresh clicked');
            const icon = this.querySelector('i');
            icon.style.animation = 'spin 0.5s ease-in-out';
            
            setTimeout(() => {
                displayUserInfo();
                icon.style.animation = '';
                showNotification('Refreshed', 'Dashboard data has been updated!', 'success');
            }, 500);
        });
    }
    
    // View Data button handler
    const viewDataBtn = document.getElementById('viewDataBtn');
    if (viewDataBtn) {
        viewDataBtn.addEventListener('click', function() {
            console.log('View Data clicked');
            showNotification(
                'Data Access', 
                'View your data and reports.\n\nThis feature allows you to view your personal data and generate reports.',
                'info'
            );
        });
    }
    
    // Theme toggle handler - CRITICAL FIX
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Theme toggle clicked');
            toggleDarkMode();
        });
        console.log('Theme toggle listener attached');
    } else {
        console.error('Theme toggle button not found!');
    }
}
// User Dashboard JavaScript - Complete Fixed Version
// Part 2: Notification System and Styles

// Notification System
function showNotification(title, message, type = 'info') {
    console.log('Showing notification:', title, type);
    
    // Remove existing notification
    let existingNotification = document.querySelector('.custom-notification');
    if (existingNotification) {
        existingNotification.remove();
    }

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `custom-notification ${type}`;
    
    // Choose icon based on type
    let icon = 'fa-info-circle';
    if (type === 'success') icon = 'fa-check-circle';
    if (type === 'warning') icon = 'fa-exclamation-triangle';
    if (type === 'error') icon = 'fa-times-circle';
    
    notification.innerHTML = `
        <div class="notification-content">
            <div class="notification-header">
                <i class="fas ${icon}"></i>
                <h3>${title}</h3>
                <button class="notification-close">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="notification-body">
                ${message.split('\n').map(line => line.trim() ? `<p>${line}</p>` : '').join('')}
            </div>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Trigger animation
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Close button handler
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    });
    
    // Auto close after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Add Notification Styles
function addNotificationStyles() {
    // Check if styles already exist
    if (document.getElementById('notification-styles')) {
        return;
    }

    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
        /* Spin Animation */
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        /* Custom Notification Styles */
        .custom-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            max-width: 420px;
            background: var(--bg-card);
            border: 2px solid var(--border-light);
            border-radius: 16px;
            box-shadow: var(--shadow-lg);
            z-index: 10000;
            transform: translateX(450px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .custom-notification.show {
            transform: translateX(0);
        }
        
        .custom-notification.info {
            border-left: 5px solid var(--info);
        }
        
        .custom-notification.success {
            border-left: 5px solid var(--success);
        }
        
        .custom-notification.warning {
            border-left: 5px solid var(--warning);
        }
        
        .custom-notification.error {
            border-left: 5px solid var(--error);
        }
        
        .notification-content {
            padding: 20px;
        }
        
        .notification-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }
        
        .notification-header i:first-child {
            font-size: 24px;
            color: var(--info);
        }
        
        .custom-notification.success .notification-header i:first-child {
            color: var(--success);
        }
        
        .custom-notification.warning .notification-header i:first-child {
            color: var(--warning);
        }
        
        .custom-notification.error .notification-header i:first-child {
            color: var(--error);
        }
        
        .notification-header h3 {
            flex: 1;
            font-size: 16px;
            font-weight: 700;
            color: var(--text-primary);
            margin: 0;
        }
        
        .notification-close {
            background: none;
            border: none;
            cursor: pointer;
            color: var(--text-muted);
            font-size: 18px;
            padding: 4px;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            border-radius: 50%;
        }
        
        .notification-close:hover {
            color: var(--text-primary);
            background: var(--bg-hover);
            transform: rotate(90deg);
        }
        
        .notification-body {
            color: var(--text-secondary);
            font-size: 14px;
            line-height: 1.6;
        }
        
        .notification-body p {
            margin: 8px 0;
        }
        
        .notification-body p:first-child {
            margin-top: 0;
        }
        
        .notification-body p:last-child {
            margin-bottom: 0;
        }
        
        /* Mobile Responsive */
        @media (max-width: 600px) {
            .custom-notification {
                right: 10px;
                left: 10px;
                max-width: none;
                top: 10px;
                transform: translateY(-150%);
            }
            
            .custom-notification.show {
                transform: translateY(0);
            }
            
            .notification-content {
                padding: 16px;
            }
            
            .notification-header h3 {
                font-size: 14px;
            }
            
            .notification-body {
                font-size: 13px;
            }
        }
        
        /* High Contrast Mode */
        @media (prefers-contrast: high) {
            .custom-notification {
                border: 3px solid var(--border-medium);
            }
        }
        
        /* Reduced Motion */
        @media (prefers-reduced-motion: reduce) {
            .custom-notification {
                transition: none;
            }
        }
    `;
    
    document.head.appendChild(style);
    console.log('Notification styles added');
}

// Prevent back navigation to login after logout
window.addEventListener('pageshow', function(event) {
    if (event.persisted) {
        // Page was loaded from cache (back button)
        checkUserAuth();
    }
});

// Additional security check
window.addEventListener('load', function() {
    checkUserAuth();
});

console.log('User Dashboard JavaScript loaded successfully');