// API Integration Helper - Connects Frontend to Backend

const API_BASE_URL = 'http://localhost:5000/api';

// API Helper Functions
const API = {
    // Contractor List APIs
    async getContractorList() {
        try {
            const response = await fetch(`${API_BASE_URL}/contractor-list`);
            if (!response.ok) throw new Error('Failed to fetch contractor list');
            return await response.json();
        } catch (error) {
            console.error('Error fetching contractor list:', error);
            return null;
        }
    },

    async saveContractorList(records) {
        try {
            const response = await fetch(`${API_BASE_URL}/contractor-list`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ records })
            });
            if (!response.ok) throw new Error('Failed to save contractor list');
            return await response.json();
        } catch (error) {
            console.error('Error saving contractor list:', error);
            throw error;
        }
    },

    // Bill Tracker APIs
    async getBillTracker() {
        try {
            const response = await fetch(`${API_BASE_URL}/bill-tracker`);
            if (!response.ok) throw new Error('Failed to fetch bill tracker');
            return await response.json();
        } catch (error) {
            console.error('Error fetching bill tracker:', error);
            return null;
        }
    },

    async saveBillTracker(records) {
        try {
            const response = await fetch(`${API_BASE_URL}/bill-tracker`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ records })
            });
            if (!response.ok) throw new Error('Failed to save bill tracker');
            return await response.json();
        } catch (error) {
            console.error('Error saving bill tracker:', error);
            throw error;
        }
    },

    // EPBG APIs
    async getEPBG() {
        try {
            const response = await fetch(`${API_BASE_URL}/epbg`);
            if (!response.ok) throw new Error('Failed to fetch EPBG');
            return await response.json();
        } catch (error) {
            console.error('Error fetching EPBG:', error);
            return null;
        }
    },

    async saveEPBG(records) {
        try {
            const response = await fetch(`${API_BASE_URL}/epbg`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ records })
            });
            if (!response.ok) throw new Error('Failed to save EPBG');
            return await response.json();
        } catch (error) {
            console.error('Error saving EPBG:', error);
            throw error;
        }
    },

    // Health Check
    async checkHealth() {
        try {
            const response = await fetch(`${API_BASE_URL}/health`);
            return await response.json();
        } catch (error) {
            console.error('Health check failed:', error);
            return { status: 'unhealthy', error: error.message };
        }
    }
};

// Sync localStorage data with backend
async function syncWithBackend(moduleType) {
    const storageKeys = {
        'contractor-list': 'dashboardData',
        'bill-tracker': 'billTrackerData',
        'epbg': 'epbgData'
    };

    const storageKey = storageKeys[moduleType];
    if (!storageKey) return;

    // Get data from localStorage
    const localData = localStorage.getItem(storageKey);
    if (!localData) return;

    try {
        const records = JSON.parse(localData);
        
        // Save to backend based on module type
        let result;
        switch (moduleType) {
            case 'contractor-list':
                result = await API.saveContractorList(records);
                break;
            case 'bill-tracker':
                result = await API.saveBillTracker(records);
                break;
            case 'epbg':
                result = await API.saveEPBG(records);
                break;
        }

        if (result && result.success) {
            console.log(`${moduleType} synced successfully:`, result.count, 'records');
        }
    } catch (error) {
        console.error(`Error syncing ${moduleType}:`, error);
    }
}

// Load data from backend to localStorage
async function loadFromBackend(moduleType) {
    const storageKeys = {
        'contractor-list': 'dashboardData',
        'bill-tracker': 'billTrackerData',
        'epbg': 'epbgData'
    };

    const storageKey = storageKeys[moduleType];
    if (!storageKey) return null;

    try {
        let data;
        switch (moduleType) {
            case 'contractor-list':
                data = await API.getContractorList();
                break;
            case 'bill-tracker':
                data = await API.getBillTracker();
                break;
            case 'epbg':
                data = await API.getEPBG();
                break;
        }

        if (data && Array.isArray(data) && data.length > 0) {
            // Convert backend format to frontend format
            const convertedData = data.map(record => {
                const converted = { ...record };
                
                // Convert date fields for contractor list
                if (record.start_date) converted.startDate = record.start_date;
                if (record.end_date) converted.endDate = record.end_date;
                
                // Convert date fields for bill tracker
                if (record.approved_date) converted.approvedDate = record.approved_date;
                if (record.approved_amount) converted.approvedAmount = record.approved_amount;
                if (record.bill_frequency) converted.billFrequency = record.bill_frequency;
                if (record.bill_date) converted.billDate = record.bill_date;
                if (record.bill_due_date) converted.billDueDate = record.bill_due_date;
                if (record.bill_paid_date) converted.billPaidDate = record.bill_paid_date;
                if (record.paid_amount) converted.paidAmount = record.paid_amount;
                
                // Convert fields for EPBG
                if (record.po_no) converted.poNo = record.po_no;
                if (record.bg_no) converted.bgNo = record.bg_no;
                if (record.bg_date) converted.bgDate = record.bg_date;
                if (record.bg_amount) converted.bgAmount = record.bg_amount;
                if (record.bg_validity) converted.bgValidity = record.bg_validity;
                if (record.gem_bid_no) converted.gemBid = record.gem_bid_no;
                if (record.ref_efile_no) converted.refEfile = record.ref_efile_no;
                
                // File fields
                if (record.file_name) converted.fileName = record.file_name;
                if (record.file_base64) converted.fileBase64 = record.file_base64;
                if (record.file_type) converted.fileType = record.file_type;
                
                return converted;
            });

            localStorage.setItem(storageKey, JSON.stringify(convertedData));
            console.log(`Loaded ${data.length} records from backend for ${moduleType}`);
            return convertedData;
        }
    } catch (error) {
        console.error(`Error loading from backend for ${moduleType}:`, error);
    }

    return null;
}

// Auto-sync on page load
document.addEventListener('DOMContentLoaded', async function() {
    // Check backend health
    const health = await API.checkHealth();
    console.log('Backend health:', health);

    // Determine current module
    const currentPage = window.location.pathname;
    let moduleType = null;

    if (currentPage.includes('index.html') || currentPage === '/') {
        moduleType = 'contractor-list';
    } else if (currentPage.includes('bill-tracker.html')) {
        moduleType = 'bill-tracker';
    } else if (currentPage.includes('epbg.html')) {
        moduleType = 'epbg';
    }

    // Load data from backend if available
    if (moduleType) {
        await loadFromBackend(moduleType);
    }
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { API, syncWithBackend, loadFromBackend };
}