const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const db = require("./db");

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));


// ---------------- LOGIN API ----------------

app.post("/login", (req, res) => {

  const { email, password } = req.body;

  const query =
    "SELECT * FROM users WHERE email=? AND password=?";

  db.query(query, [email, password], (err, result) => {

    if (err) {
      console.log(err);
      return res.json({ error: "Database Error" });
    }

    if (result.length > 0) {

      const userRole = result[0].role;

      return res.json({
        msg: "Login Success",
        role: userRole
      });

    } else {

      return res.json({
        error: "Invalid Email or Password"
      });

    }

  });

});


// ---------------- SERVER START ----------------

app.listen(3000, () => {
  console.log("Server Running On Port 3000");
});
