function login() {

  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  fetch("http://localhost:3000/login", {

    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },

    body: JSON.stringify({
      email: email,
      password: password
    })

  })
  .then(res => res.json())
  .then(data => {

    if (data.role === "admin") {
      window.location.href = "admin-dashboard.html";
    }

    else if (data.role === "staff") {
      window.location.href = "staff-dashboard.html";
    }

    else {
      alert("Invalid Login");
    }

  });

}
